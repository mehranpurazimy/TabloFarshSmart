package com.example.tablofarsh

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MainScreen() } }
    }
}

private data class Pattern(
    val bitmap: Bitmap,
    val palette: List<Int>,
    val gridWidth: Int,
    val gridHeight: Int
)

@Composable
private fun MainScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var pattern by remember { mutableStateOf<Pattern?>(null) }
    var colorCount by remember { mutableFloatStateOf(32f) }
    var gridWidth by remember { mutableFloatStateOf(100f) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("برای شروع، یک عکس انتخاب کن.") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    val bmp = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use {
                            BitmapFactory.decodeStream(it)
                        }
                    }
                    original = bmp
                    pattern = null
                    message = if (bmp != null) "عکس آماده است؛ تعداد رنگ و خانه‌ها را تنظیم کن." else "خواندن عکس ناموفق بود."
                } catch (_: Exception) {
                    message = "خواندن عکس ناموفق بود."
                } finally { busy = false }
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = ComposeColor(0xFFF7F4EF)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("تابلوفرش هوشمند", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ComposeColor(0xFF4B3427))
            Text("تبدیل عکس به نقشه خانه‌به‌خانه", fontSize = 14.sp, color = ComposeColor(0xFF806B5C))
            Spacer(Modifier.height(18.dp))

            Button(
                onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ComposeColor(0xFF795548))
            ) { Text("انتخاب عکس از گالری") }

            Spacer(Modifier.height(12.dp))
            original?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "عکس انتخاب‌شده",
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                        .border(1.dp, ComposeColor(0xFFD7C7B8), RoundedCornerShape(12.dp))
                )
            } ?: Box(
                Modifier.fillMaxWidth().height(150.dp)
                    .background(ComposeColor(0xFFEDE5DC), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Text("پیش‌نمایش عکس", color = ComposeColor(0xFF806B5C)) }

            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = ComposeColor.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("تعداد رنگ نخ: ${colorCount.toInt()}", fontWeight = FontWeight.Bold)
                    Slider(
                        value = colorCount, onValueChange = { colorCount = it; pattern = null },
                        valueRange = 8f..96f, steps = 10
                    )
                    Text("تعداد خانه در عرض نقشه: ${gridWidth.toInt()}", fontWeight = FontWeight.Bold)
                    Slider(
                        value = gridWidth, onValueChange = { gridWidth = it; pattern = null },
                        valueRange = 40f..200f, steps = 15
                    )
                    Text("با افزایش تعداد خانه‌ها، جزئیات بیشتر و نقشه بزرگ‌تر می‌شود.", fontSize = 12.sp, color = ComposeColor.Gray)
                }
            }

            Spacer(Modifier.height(12.dp))
            Button(
                enabled = original != null && !busy,
                onClick = {
                    val source = original ?: return@Button
                    busy = true
                    scope.launch {
                        pattern = withContext(Dispatchers.Default) {
                            makePattern(source, colorCount.toInt(), gridWidth.toInt())
                        }
                        message = "نقشه اولیه ساخته شد. این نسخه برای آزمایش الگوریتم است."
                        busy = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ComposeColor(0xFF4E7560))
            ) { Text(if (busy) "در حال پردازش..." else "تبدیل به نقشه تابلوفرش") }

            pattern?.let { p ->
                Spacer(Modifier.height(14.dp))
                Text("پیش‌نمایش نقشه", fontWeight = FontWeight.Bold)
                Image(
                    bitmap = p.bitmap.asImageBitmap(),
                    contentDescription = "نقشه رنگی",
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                        .border(1.dp, ComposeColor.DarkGray)
                )
                Text("ابعاد: ${p.gridWidth} × ${p.gridHeight} خانه | ${p.palette.size} رنگ")
                Text("پالت رنگ", fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    p.palette.forEachIndexed { index, color ->
                        Column(Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(25.dp).background(ComposeColor(color)).border(1.dp, ComposeColor.Gray))
                            Text("${index + 1}", fontSize = 10.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(message, fontSize = 12.sp, color = ComposeColor(0xFF6D5A4D))
            Spacer(Modifier.weight(1f))
            OutlinedButton(
                onClick = { message = "اتصال هوش مصنوعی در مرحله بعد با سرور امن اضافه می‌شود؛ کلید API نباید داخل APK قرار بگیرد." },
                modifier = Modifier.fillMaxWidth()
            ) { Text("ویرایش دلخواه با هوش مصنوعی (مرحله بعد)") }
            Text("نسخه آزمایشی ۰٫۱", fontSize = 10.sp, color = ComposeColor.Gray)
        }
    }
}

private fun makePattern(source: Bitmap, requestedColors: Int, requestedWidth: Int): Pattern {
    val ratio = source.height.toFloat() / source.width.toFloat()
    val w = requestedWidth.coerceIn(40, 200)
    val h = (w * ratio).toInt().coerceIn(40, 300)
    val small = Bitmap.createScaledBitmap(source, w, h, true)
    val pixels = IntArray(w * h)
    small.getPixels(pixels, 0, w, 0, 0, w, h)

    // Deterministic color quantization: iterative RGB k-means.
    val k = requestedColors.coerceIn(8, 96).coerceAtMost(pixels.distinct().size)
    val centers = MutableList(k) { i ->
        val c = pixels[(i * pixels.size / k).coerceIn(0, pixels.lastIndex)]
        floatArrayOf(Color.red(c).toFloat(), Color.green(c).toFloat(), Color.blue(c).toFloat())
    }
    val assignments = IntArray(pixels.size)
    repeat(7) {
        val sums = Array(k) { FloatArray(3) }
        val counts = IntArray(k)
        for (i in pixels.indices) {
            val c = pixels[i]
            var best = 0
            var bestD = Float.MAX_VALUE
            for (j in 0 until k) {
                val dr = Color.red(c) - centers[j][0]
                val dg = Color.green(c) - centers[j][1]
                val db = Color.blue(c) - centers[j][2]
                val d = dr * dr + dg * dg + db * db
                if (d < bestD) { bestD = d; best = j }
            }
            assignments[i] = best
            sums[best][0] += Color.red(c); sums[best][1] += Color.green(c); sums[best][2] += Color.blue(c)
            counts[best]++
        }
        for (j in 0 until k) if (counts[j] > 0) {
            centers[j][0] = sums[j][0] / counts[j]
            centers[j][1] = sums[j][1] / counts[j]
            centers[j][2] = sums[j][2] / counts[j]
        }
    }

    val palette = centers.map {
        Color.rgb(it[0].toInt().coerceIn(0,255), it[1].toInt().coerceIn(0,255), it[2].toInt().coerceIn(0,255))
    }
    val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    for (i in pixels.indices) output.setPixel(i % w, i / w, palette[assignments[i]])
    return Pattern(output, palette, w, h)
}
